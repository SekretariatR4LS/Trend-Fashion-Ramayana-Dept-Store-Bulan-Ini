fetch('data/produk.json')
  .then(res => res.json())
  .then(data => {
    const container = document.getElementById('produk-container');
    data.forEach(produk => {
      const card = document.createElement('div');
      card.className = 'card';
      card.innerHTML = `
        <img src="\${produk.foto}" alt="\${produk.nama}" />
        <h3>\${produk.nama}</h3>
        <p>\${produk.deskripsi}</p>
        <p><strong>Usia:</strong> \${produk.usia}</p>
        <p><strong>Ukuran:</strong> \${produk.ukuran.join(', ')}</p>
        <p><strong>Warna:</strong> \${produk.warna.join(', ')}</p>
        <p><strong>Harga:</strong> Rp \${produk.harga.toLocaleString()}</p>
      `;
      container.appendChild(card);
    });
  });
